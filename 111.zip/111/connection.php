<?php
$cn = mysqli_connect('localhost','root','','my_work');

?>


