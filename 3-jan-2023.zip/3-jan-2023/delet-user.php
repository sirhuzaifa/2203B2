<?php
 include("connection.php");
 $Id=$_GET['Id'];
 mysqli_query($con, "delete from user where id = ".$_GET["id"]." ");
 echo "<script>window.location.assign('index.php')</script>";
?>