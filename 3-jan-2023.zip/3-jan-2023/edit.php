<!doctype html>
<html lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title> Edit </title>
    <link rel="stylesheet" href="stylesheet.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" 
    crossorigin="anonymous"></script>

  <head>

  </head>
  <body>

  <?php
  include("navbar.php");
  ?>

  <br>
  

<?php

include("connection.php");
$data = mysqli_query($con,"select * from user where id = ".$_GET["id"]." ");
if($abc_data = mysqli_fetch_array($data)){
?>

<div class="container">
    <div class="login-form">
      <h1 Id="h1"> UPDATE FORM </h1>
      <form method='POST'>
        <input class="form-control" type="text" name="Name" placeholder="Enter your Name" required>
        <br><br>
        <input class="form-control" type="text" name="Email" placeholder="Enter your Email" required>
        <br><br>
        <input name="btn" type="submit" class="btn btn-success btn1234" value="Submit" required>
      </form>


<?php }
 ?>

</div>
</div>

<?php 

include("connection.php");
if(isset($_POST["btn"])){

    mysqli_query($con,"update user set Name = '".$_POST["Name"]."',Email = '".$_POST["Email"]."'  where id = ".$_GET["id"]." ");
    echo "<script>alert('Updated')</script>";
    echo "<script>window.location.assign('index.php')</script>";
    
}

?>

<br>

<?php
include("footer.php");
?>

</body>
</html>