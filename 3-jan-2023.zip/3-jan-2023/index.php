<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> INDEX </title>

    <link rel="stylesheet" href="stylesheet.css">

        <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" 
integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</head>
<body>

<?php

 /*Include_Navbar*/ 

include("navbar.php");

if(!isset($_SESSION["name"])){
  echo "<script>window.location.assign('login.php')</script>";
 } 

?>

<br>
<h2> Welcome To The PHP Website </h2>
  <h4>Class Task</h4>

<br>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Status</th>
      <th scope="col">Update</th>
      <th scope="col">Action</th>

    </tr>
  </thead>
  <tbody>

      <?php
      include("connection.php");
      $data = mysqli_query($con, "select * from user");
      $i = 1;
      while($user_data = mysqli_fetch_array($data)){
      ?>
    
    <tr>
      <td scope="row"><?php echo $i ?></td>
      <td ><?php echo $user_data["Name"] ?></td>
      <td><?php echo $user_data["Email"] ?></td>
      <td><?php echo $user_data["Password"] ?></td>
      <td><a><?php echo $user_data["Status"] ?></a></td>
      <td><a class="btn btn-success btn1234" href="edit.php?id=<?php echo $user_data["Id"]?>">Edit</a></td>
      <td><a class="btn btn-danger btn1234" href="delet-user.php?id=<?php echo $user_data["Id"] ?>">Delet</a></td>
    </tr>

    <?php $i++; } ?>

  </tbody>
</table>


<br>

<a class="btn btn-dark btnpr" href="insert.php"> Create New User </a>

<br><br><br><br><br>

<?php

 /*Include_Footer*/ 

include("footer.php");

?>
    
</body>
</html>