<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" 
    crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

    <link rel="stylesheet" href="stylesheet.css">

    <title>Log-in</title>
  </head>
  <body>
  

  <?php
    include("navbar.php");


    if(isset($_SESSION["name"])){
        echo "<script>window.location.assign('index.php')</script>";
       } 
  ?>


<h1> LOG-IN FORM </h1>

<form method="POST">

    <label  for="name" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" placeholder="Enter your Email">
    <br>
    <label  for="name" class="form-label">Password</label>
    <input type="password" name="password" class="form-control" placeholder="Enter your Password">
    <br>
    <br>

    <button type="submit" name="btn" class="btn btn-dark">Login</button>
</form>


<?php
    include("footer.php");
  ?>




<?php 
  include('connection.php');
  if(isset($_POST["btn"])){

    $data = mysqli_query($con,"select * from user where email = '".$_POST["email"]."' and password = '".md5($_POST["password"])."' ");
    if($user_data = mysqli_fetch_array($data)){
        $_SESSION["name"] = $user_data["name"];
        echo "<script>alert('Logged In')</script>";
        echo "<script>window.location.assign('index.php')</script>";
    }
    else{
        echo "<script>alert('Invalid')</script>";
    }
  }

?>



  </body>
</html>