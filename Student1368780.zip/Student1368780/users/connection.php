<?php

$con = mysqli_connect("localhost","root","","Student1368780");

?>