<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<title>Edit</title>
</head>

<body>

 <?php 
 include("nav.php");
?>

<h1>Edit</h1>
<?php
include("connection.php");
$data = mysqli_query($con, "select * from users where id = ".$_GET["id"]." ");
if($std_data = mysqli_fetch_array($data)){
?>

<form method="POST">
  <input type="username" name="username" class="form-control" value="<?php echo $std_data["username"] ?>" placeholder="enter Your name" >
  <br>
  <input type="useremail" name="useremail" class="form-control" value="<?php echo $std_data["useremail"] ?>" placeholder="enter Your email" >
  <br>
  <input type="userphone" name="userphone" class="form-control" value="<?php echo $std_data["userphone"] ?>" placeholder="enter Your phone " >
  <br>
  <button type="submit" name="btn" class="btn btn-dark">Update</button>
</form>



<?php } ?>

<?php
include("footer.php");
?>

<?php
include("connection.php");
if(isset($_POST["btn"])){

    mysqli_query($con,"update users set name ='".$_POST["username"]."',email = '".$_POST["useremail"]."',phone = '".$_POST["userphone"]."' where id = ".$_GET["id"]." ");
    echo "<script>alert('uptated')</script>";
    echo "<script>window.location.assign('showdata.php')</script>";
}

?>

</body>
</html>