<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<style>
    body{
       background-image:url("bg.webp");
       background-size:cover;
    }
    h1{
        text-align:center;
    }
    form{
        font-size:20px;
    }
</style>

</head>

<body>

 <?php 
 include("nav.php");
?>

<h1>INSERT</h1>


<form method="POST">
  <input type="username" name="username" class="form-control" placeholder="enter Your name" >
  <br>
  <input type="useremail" name="useremail" class="form-control" placeholder="enter Your email" >
  <br>
  <input type="userpassword" name="userpassword" class="form-control" placeholder="enter Your password" >
  <br>
  <input type="userphone" name="userphone" class="form-control" placeholder="enter Your phone " >
  <br>
  <input type="useraddress" name="useraddress" class="form-control" placeholder="enter Your address" >
  <br>
  <button type="submit" name="btn" class="btn btn-dark">SUBMIT</button>
</form>
    
<?php
include("footer.php");
?>

<?php
include("business_logic.php");
insert_query("btn","insert into users(username,useremail,userpassword,userphone,useraddress) values('".$_POST["username"]."','".$_POST["useremail"]."','".$_POST["userpassword"]."','".$_POST["userphone"]."','".$_POST["useraddress"]."')");
?>

</body>
</html>