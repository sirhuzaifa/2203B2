<?php
include("connection.php");
mysqli_query($con,"delete from blog where id = ".$_GET["id"]." ") ;
echo "<script>window.location.assign('blog_table.php')</script>";

?>