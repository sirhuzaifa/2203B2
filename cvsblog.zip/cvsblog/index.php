<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>Hello, world!</title>
  </head>
  <body>

  <?php
  
  include("navbar.php");
  ?>


    <h1 style="text-align:center">Blogs</h1>


<center>
    <div id="carouselExampleInterval" style="width:80%" class="carousel slide" data-bs-ride="carousel" >
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="images/img1.jpg" class="d-block w-100" alt="..." style="height:500px;border-radius:5%">
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="images/img2.jpg" class="d-block w-100" alt="..."style="height:500px;border-radius:5%" >
    </div>
    <div class="carousel-item">
    <img src="images/img4.jpg" class="d-block w-100" alt="..." style="height:500px;border-radius:5%" >
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

</center>

    <div class="accordion accordion-flush" id="accordionFlushExample" style="padding:5%">


    <?php
include("connection.php");

$i=0;
  $data =   mysqli_query($con,"SELECT blog.id,blog.title,blog.discription as description  ,blog_cate.name,blog.created_at ,person.name as p_name FROM blog INNER JOIN blog_cate on blog.blog_cat_id = blog_cate.id inner join person on blog.person_id = person.id");
  while($blog = mysqli_fetch_array($data)){
?>


  <div class="accordion-item" style="border:solid #ADD8E6;">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo $i ?>" aria-expanded="false" aria-controls="flush-collapseOne">
        <?php echo $blog["title"] ?>

        <div id="get_value"></div>

      </button>
    </h2>
    <div id="flush-collapse<?php echo $i ?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body"> <?php
      
      echo "Blog Category : ".$blog["name"]."<br>Published DateTime : ".$blog["created_at"].".<br>Publisher : ".$blog["p_name"]."<br><br>". $blog["description"] ?>
      <br>
      <button onclick="rect('like','<?php echo $blog['id'] ?>')"><i style="color:blue;"  class="fa fa-thumbs-up" aria-hidden="true"></i></button>
     <button onclick="rect('dislike','<?php echo $blog['id'] ?>')" > <i style="color:red;"  class="fa fa-thumbs-down" aria-hidden="true"></i></button>
    </div>
    </div>
  </div>
  <br>


  <?php $i++; } ?>



 
</div>








<script>
    function rect(reaction,blog_id){

       // alert(reaction+blog_id);
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("get_value").innerHTML = this.responseText;
      }
      else if(this.status == 404){
        document.getElementById("get_value").innerHTML = "Page not Found";
      }
    };
    xmlhttp.open("GET","reaction.php?reaction="+reaction+"&blog_id="+blog_id,true);
    xmlhttp.send();

    }
  </script>



    
  <?php
  
  include("footer.php");
  ?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>