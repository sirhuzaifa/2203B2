
<h1>
<?php 
session_start();
$rect =  $_GET["reaction"];
$blog_id = $_GET["blog_id"];

include("connection.php");

    mysqli_query($con,"insert into reaction(reaction_name,blog_id,person_id) values ('".$rect."','".$blog_id."','".$_SESSION["userid"]."')");
  

    $data =   mysqli_query($con,"SELECT count(*) as like_post from reaction where reaction_name = 'like' ");
    if($blog = mysqli_fetch_array($data)){

        echo "<p>(Like : ".$blog["like_post"].")</p>";


    }

?>



</h1>