<?php
$con=mysqli_connect('localhost','root','','APTECH_NN');

?>