<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> INSERT </title>

     <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" 
integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="stylesheet.css">

</head>
<body>

<?php  

   /*Include_Navbar*/

include("navbar.php");

?>

<br>

    <div class="container">

<form method='POST'>

<div class="mb-3">
    <label  for="name" class="form-label">Name</label>
    <input type="text" name='name' class="form-control"  placeholder="Enter your Name" required>
</div>

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label" >Email address</label>
    <input type="email" name="email" class="form-control"  placeholder="Enter your Email" required>
   
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" name="password" class="form-control"  placeholder="Enter your Password" required>
  </div>

        <label class="form-label">Image</label>
        <input type="file" name="userfile" class="form-control" require>

        <br><br>
 
  <button type="submit" name="btn" class="btn btn-success btn123"> Submit </button>
</form>
    </div>

    <br><br>

<?php

 /*Include_Footer*/ 

include("footer.php");

?>

    <?php 

  insert_query("btn","insert into user(Name,Email,Password) values ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["password"]."')");

  function insert_query($btn_name,$query){
    include('connection.php');
    if(isset($_POST[$btn_name])){
      mysqli_query($con,$query);
      move_uploaded_file($_FILES["userfile"]["tmp_name"],"images/".mysqli_insert_id($con).".jpeg");
      echo "<script>alert('Insert') 
      window.location.assign('index.php')</script>";
      
    }
  }

  ?>
  

</body>
</html>