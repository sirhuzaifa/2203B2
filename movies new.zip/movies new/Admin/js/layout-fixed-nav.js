(function($) {
    "use strict"

    new quixSettings({
        sidebarPosition: "fixed"
    });


})(jQuery);