<?php

session_start();

session_destroy();

echo "<script>window.location.assign('page-login.php')</script>";

?>