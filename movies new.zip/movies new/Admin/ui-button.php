<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Focus - Bootstrap Admin Dashboard </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="./css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="index.html" class="brand-logo">
                <img class="logo-abbr" src="./images/logo.png" alt="">
                <img class="logo-compact" src="./images/logo-text.png" alt="">
                <img class="brand-title" src="./images/logo-text.png" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="search_bar dropdown">
                                <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <div class="dropdown-menu p-0 m-0">
                                    <form>
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                                    </form>
                                </div>
                            </div>
                        </div>

                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown notification_dropdown">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-bell"></i>
                                    <div class="pulse-css"></div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <ul class="list-unstyled">
                                        <li class="media dropdown-item">
                                            <span class="success"><i class="ti-user"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Martin</strong> has added a <strong>customer</strong> Successfully
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="primary"><i class="ti-shopping-cart"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Jennifer</strong> purchased Light Dashboard 2.0.</p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="danger"><i class="ti-bookmark"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Robin</strong> marked a <strong>ticket</strong> as unsolved.
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="primary"><i class="ti-heart"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>David</strong> purchased Light Dashboard 1.0.</p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="success"><i class="ti-image"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong> James.</strong> has added a<strong>customer</strong> Successfully
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                    </ul>
                                    <a class="all-notification" href="#">See all notifications <i
                                            class="ti-arrow-right"></i></a>
                                </div>
                            </li>
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-account"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="./app-profile.html" class="dropdown-item">
                                        <i class="icon-user"></i>
                                        <span class="ml-2">Profile </span>
                                    </a>
                                    <a href="./email-inbox.html" class="dropdown-item">
                                        <i class="icon-envelope-open"></i>
                                        <span class="ml-2">Inbox </span>
                                    </a>
                                    <a href="./page-login.html" class="dropdown-item">
                                        <i class="icon-key"></i>
                                        <span class="ml-2">Logout </span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="quixnav">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label first">Main Menu</li>
                    <!-- <li><a href="index.html"><i class="icon icon-single-04"></i><span class="nav-text">Dashboard</span></a>
                    </li> -->
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-single-04"></i><span class="nav-text">Dashboard</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./index.html">Dashboard 1</a></li>
                            <li><a href="./index2.html">Dashboard 2</a></li></ul>
                    </li>
                    
                    <li class="nav-label">Apps</li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-app-store"></i><span class="nav-text">Apps</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./app-profile.html">Profile</a></li>
                            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Email</a>
                                <ul aria-expanded="false">
                                    <li><a href="./email-compose.html">Compose</a></li>
                                    <li><a href="./email-inbox.html">Inbox</a></li>
                                    <li><a href="./email-read.html">Read</a></li>
                                </ul>
                            </li>
                            <li><a href="./app-calender.html">Calendar</a></li>
                        </ul>
                    </li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-chart-bar-33"></i><span class="nav-text">Charts</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./chart-flot.html">Flot</a></li>
                            <li><a href="./chart-morris.html">Morris</a></li>
                            <li><a href="./chart-chartjs.html">Chartjs</a></li>
                            <li><a href="./chart-chartist.html">Chartist</a></li>
                            <li><a href="./chart-sparkline.html">Sparkline</a></li>
                            <li><a href="./chart-peity.html">Peity</a></li>
                        </ul>
                    </li>
                    <li class="nav-label">Components</li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-world-2"></i><span class="nav-text">Bootstrap</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./ui-accordion.html">Accordion</a></li>
                            <li><a href="./ui-alert.html">Alert</a></li>
                            <li><a href="./ui-badge.html">Badge</a></li>
                            <li><a href="./ui-button.html">Button</a></li>
                            <li><a href="./ui-modal.html">Modal</a></li>
                            <li><a href="./ui-button-group.html">Button Group</a></li>
                            <li><a href="./ui-list-group.html">List Group</a></li>
                            <li><a href="./ui-media-object.html">Media Object</a></li>
                            <li><a href="./ui-card.html">Cards</a></li>
                            <li><a href="./ui-carousel.html">Carousel</a></li>
                            <li><a href="./ui-dropdown.html">Dropdown</a></li>
                            <li><a href="./ui-popover.html">Popover</a></li>
                            <li><a href="./ui-progressbar.html">Progressbar</a></li>
                            <li><a href="./ui-tab.html">Tab</a></li>
                            <li><a href="./ui-typography.html">Typography</a></li>
                            <li><a href="./ui-pagination.html">Pagination</a></li>
                            <li><a href="./ui-grid.html">Grid</a></li>

                        </ul>
                    </li>

                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-plug"></i><span class="nav-text">Plugins</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./uc-select2.html">Select 2</a></li>
                            <li><a href="./uc-nestable.html">Nestedable</a></li>
                            <li><a href="./uc-noui-slider.html">Noui Slider</a></li>
                            <li><a href="./uc-sweetalert.html">Sweet Alert</a></li>
                            <li><a href="./uc-toastr.html">Toastr</a></li>
                            <li><a href="./map-jqvmap.html">Jqv Map</a></li>
                        </ul>
                    </li>
                    <li><a href="widget-basic.html" aria-expanded="false"><i class="icon icon-globe-2"></i><span
                                class="nav-text">Widget</span></a></li>
                    <li class="nav-label">Forms</li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-form"></i><span class="nav-text">Forms</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./form-element.html">Form Elements</a></li>
                            <li><a href="./form-wizard.html">Wizard</a></li>
                            <li><a href="./form-editor-summernote.html">Summernote</a></li>
                            <li><a href="form-pickers.html">Pickers</a></li>
                            <li><a href="form-validation-jquery.html">Jquery Validate</a></li>
                        </ul>
                    </li>
                    <li class="nav-label">Table</li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-layout-25"></i><span class="nav-text">Table</span></a>
                        <ul aria-expanded="false">
                            <li><a href="table-bootstrap-basic.html">Bootstrap</a></li>
                            <li><a href="table-datatable-basic.html">Datatable</a></li>
                        </ul>
                    </li>

                    <li class="nav-label">Extra</li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                                class="icon icon-single-copy-06"></i><span class="nav-text">Pages</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./page-register.html">Register</a></li>
                            <li><a href="./page-login.html">Login</a></li>
                            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Error</a>
                                <ul aria-expanded="false">
                                    <li><a href="./page-error-400.html">Error 400</a></li>
                                    <li><a href="./page-error-403.html">Error 403</a></li>
                                    <li><a href="./page-error-404.html">Error 404</a></li>
                                    <li><a href="./page-error-500.html">Error 500</a></li>
                                    <li><a href="./page-error-503.html">Error 503</a></li>
                                </ul>
                            </li>
                            <li><a href="./page-lock-screen.html">Lock Screen</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body btn-page">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Hi, welcome back!</h4>
                            <span class="ml-1">Buttons</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Bootstrap</a></li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Buttons</a></li>
                        </ol>
                    </div>
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Buttons</h4>
                                <p class="mb-0 subtitle">Default button style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-primary">Primary</button>
                                <button type="button" class="btn btn-secondary">Secondary</button>
                                <button type="button" class="btn btn-success">Success</button>
                                <button type="button" class="btn btn-danger">Danger</button>
                                <button type="button" class="btn btn-warning">Warning</button>
                                <button type="button" class="btn btn-info">Info</button>
                                <button type="button" class="btn btn-light">Light</button>
                                <button type="button" class="btn btn-dark">Dark</button>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Outline Buttons</h4>
                                <p class="mb-0 subtitle">Default outline button style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-outline-primary">Primary</button>
                                <button type="button" class="btn btn-outline-secondary">Secondary</button>
                                <button type="button" class="btn btn-outline-success">Success</button>
                                <button type="button" class="btn btn-outline-danger">Danger</button>
                                <button type="button" class="btn btn-outline-warning">Warning</button>
                                <button type="button" class="btn btn-outline-info">Info</button>
                                <button type="button" class="btn btn-outline-light">Light</button>
                                <button type="button" class="btn btn-outline-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Button Sizes</h4>
                                <p class="mb-0 subtitle">add <code>.btn-lg .btn-sm .btn-xs</code> to change the style
                                </p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-primary btn-lg">Large Button</button>
                                <button type="button" class="btn btn-primary">Default Button</button>
                                <button type="button" class="btn btn-primary btn-sm">Small Button</button>
                                <button type="button" class="btn btn-primary btn-xs">Extra Small Button</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Outline Button Sizes</h4>
                                <p class="mb-0 subtitle">add <code>.btn-lg .btn-sm .btn-xs</code> to change the style
                                </p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-outline-primary btn-lg">Large button</button>
                                <button type="button" class="btn btn-outline-primary">Default button</button>
                                <button type="button" class="btn btn-outline-primary btn-sm">Small button</button>
                                <button type="button" class="btn btn-outline-primary btn-xs">Extra small button</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Rounded Buttons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-rounded</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                                <button type="button" class="btn btn-rounded btn-primary">Primary</button>
                                <button type="button" class="btn btn-rounded btn-secondary">Secondary</button>
                                <button type="button" class="btn btn-rounded btn-success">Success</button>
                                <button type="button" class="btn btn-rounded btn-danger">Danger</button>
                                <button type="button" class="btn btn-rounded btn-warning">Warning</button>
                                <button type="button" class="btn btn-rounded btn-info">Info</button>
                                <button type="button" class="btn btn-rounded btn-light">Light</button>
                                <button type="button" class="btn btn-rounded btn-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Rounded outline Buttons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-rounded</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <div class="rounded-button">
                                    <button type="button" class="btn btn-rounded btn-outline-primary">Primary</button>
                                    <button type="button" class="btn btn-rounded btn-outline-secondary">Secondary</button>
                                    <button type="button" class="btn btn-rounded btn-outline-success">Success</button>
                                    <button type="button" class="btn btn-rounded btn-outline-danger">Danger</button>
                                    <button type="button" class="btn btn-rounded btn-outline-warning">Warning</button>
                                    <button type="button" class="btn btn-rounded btn-outline-info">Info</button>
                                    <button type="button" class="btn btn-rounded btn-outline-light">Light</button>
                                    <button type="button" class="btn btn-rounded btn-outline-dark">Dark</button>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Button Right icons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-icon-right</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-primary">Add to cart <span
                                        class="btn-icon-right"><i class="fa fa-shopping-cart"></i></span>
                                </button>
                                <button type="button" class="btn btn-info">Add to wishlist <span
                                        class="btn-icon-right"><i class="fa fa-heart"></i></span>
                                </button>
                                <button type="button" class="btn btn-danger">Remove <span class="btn-icon-right"><i
                                            class="fa fa-close"></i></span>
                                </button>
                                <button type="button" class="btn btn-secondary">Sent message <span
                                        class="btn-icon-right"><i class="fa fa-envelope"></i></span>
                                </button>
                                <button type="button" class="btn btn-warning">Add bookmark <span
                                        class="btn-icon-right"><i class="fa fa-star"></i></span>
                                </button>
                                <button type="button" class="btn btn-success">Success <span class="btn-icon-right"><i
                                            class="fa fa-check"></i></span>
                                </button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Button Left icons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-icon-left</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-rounded btn-primary"><span
                                        class="btn-icon-left text-primary"><i class="fa fa-shopping-cart"></i>
                                    </span>Buy</button>
                                <button type="button" class="btn btn-rounded btn-info"><span
                                        class="btn-icon-left text-info"><i class="fa fa-plus color-info"></i>
                                    </span>Add</button>
                                <button type="button" class="btn btn-rounded btn-danger"><span
                                        class="btn-icon-left text-danger"><i class="fa fa-envelope color-danger"></i>
                                    </span>Email</button>
                                <button type="button" class="btn btn-rounded btn-secondary"><span
                                        class="btn-icon-left text-secondary"><i
                                            class="fa fa-share-alt color-secondary"></i> </span>Share</button>
                                <button type="button" class="btn btn-rounded btn-warning"><span
                                        class="btn-icon-left text-warning"><i class="fa fa-download color-warning"></i>
                                    </span>Download</button>
                                <button type="button" class="btn btn-rounded btn-success"><span
                                        class="btn-icon-left text-success"><i class="fa fa-upload color-success"></i>
                                    </span>Upload</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Square Buttons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-square</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn  btn-square btn-primary">Primary</button>
                                <button type="button" class="btn  btn-square btn-secondary">Secondary</button>
                                <button type="button" class="btn  btn-square btn-success">Success</button>
                                <button type="button" class="btn  btn-square btn-danger">Danger</button>
                                <button type="button" class="btn  btn-square btn-warning">Warning</button>
                                <button type="button" class="btn  btn-square btn-info">Info</button>
                                <button type="button" class="btn  btn-square btn-light">Light</button>
                                <button type="button" class="btn  btn-square btn-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Square Outline Buttons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-square</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-square btn-outline-primary">Primary</button>
                                <button type="button" class="btn btn-square btn-outline-secondary">Secondary</button>
                                <button type="button" class="btn btn-square btn-outline-success">Success</button>
                                <button type="button" class="btn btn-square btn-outline-danger">Danger</button>
                                <button type="button" class="btn btn-square btn-outline-warning">Warning</button>
                                <button type="button" class="btn btn-square btn-outline-info">Info</button>
                                <button type="button" class="btn btn-square btn-outline-light">Light</button>
                                <button type="button" class="btn btn-square btn-outline-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Rounded Button</h4>
                                <p class="mb-0 subtitle">add <code>.btn-rounded</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-rounded btn-primary">Primary</button>
                                <button type="button" class="btn btn-rounded btn-secondary">Secondary</button>
                                <button type="button" class="btn btn-rounded btn-success">Success</button>
                                <button type="button" class="btn btn-rounded btn-danger">Danger</button>
                                <button type="button" class="btn btn-rounded btn-warning">Warning</button>
                                <button type="button" class="btn btn-rounded btn-info">Info</button>
                                <button type="button" class="btn btn-rounded btn-light">Light</button>
                                <button type="button" class="btn btn-rounded btn-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Rounded outline Buttons</h4>
                                <p class="mb-0 subtitle">add <code>.btn-rounded</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-rounded btn-outline-primary">Primary</button>
                                <button type="button" class="btn btn-rounded btn-outline-secondary">Secondary</button>
                                <button type="button" class="btn btn-rounded btn-outline-success">Success</button>
                                <button type="button" class="btn btn-rounded btn-outline-danger">Danger</button>
                                <button type="button" class="btn btn-rounded btn-outline-warning">Warning</button>
                                <button type="button" class="btn btn-rounded btn-outline-info">Info</button>
                                <button type="button" class="btn btn-rounded btn-outline-light">Light</button>
                                <button type="button" class="btn btn-rounded btn-outline-dark">Dark</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Dropdown Button</h4>
                                <p class="mb-0 subtitle">Default dropdown button style</p>
                            </div>
                            <div class="card-body">
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Primary</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                    </div>
                                </div>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">Secondary</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                    </div>
                                </div>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">Success</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                    </div>
                                </div>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">Warning</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                    </div>
                                </div>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">Danger</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                        <a class="dropdown-item" href="javascript:void()">Dropdown link</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Disabled Button</h4>
                                <p class="mb-0 subtitle">add <code>disabled="disabled"</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-rounded btn-primary" disabled="disabled">Primary</button>
                                <button type="button" class="btn btn-rounded btn-secondary" disabled="disabled">Secondary</button>
                                <button type="button" class="btn btn-rounded btn-success" disabled="disabled">Success</button>
                                <button type="button" class="btn btn-rounded btn-danger" disabled="disabled">Danger</button>
                                <button type="button" class="btn btn-rounded btn-warning" disabled="disabled">Warning</button>
                                <button type="button" class="btn btn-rounded btn-info" disabled="disabled">Info</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title">Socia icon Buttons with Name</h4>
                                <p class="mb-0 subtitle">add <code>.btn-facebook, .btn-twitter, .btn-youtube...</code> to change the style</p>
                            </div>
                            <div class="card-body">
                                <button type="button" class="btn btn-facebook">Facebook <span class="btn-icon-right"><i
                                            class="fa fa-facebook"></i></span>
                                </button>
                                <button type="button" class="btn btn-twitter">Twitter <span class="btn-icon-right"><i
                                            class="fa fa-twitter"></i></span>
                                </button>
                                <button type="button" class="btn btn-youtube">Youtube <span class="btn-icon-right"><i
                                            class="fa fa-youtube"></i></span>
                                </button>
                                <button type="button" class="btn btn-instagram">Instagram <span
                                        class="btn-icon-right"><i class="fa fa-instagram"></i></span>
                                </button>
                                <button type="button" class="btn btn-pinterest">Pinterest <span
                                        class="btn-icon-right"><i class="fa fa-pinterest"></i></span>
                                </button>
                                <button type="button" class="btn btn-linkedin">Linkedin <span class="btn-icon-right"><i
                                            class="fa fa-linkedin"></i></span>
                                </button>
                                <button type="button" class="btn btn-google-plus">Google + <span
                                        class="btn-icon-right"><i class="fa fa-google-plus"></i></span>
                                </button>
                                <button type="button" class="btn btn-google">Google <span class="btn-icon-right"><i
                                            class="fa fa-google"></i></span>
                                </button>
                                <button type="button" class="btn btn-snapchat">Snapchat <span class="btn-icon-right"><i
                                            class="fa fa-snapchat"></i></span>
                                </button>
                                <button type="button" class="btn btn-whatsapp">Whatsapp <span class="btn-icon-right"><i
                                            class="fa fa-whatsapp"></i></span>
                                </button>
                                <button type="button" class="btn btn-tumblr">Tumblr <span class="btn-icon-right"><i
                                            class="fa fa-tumblr"></i></span>
                                </button>
                                <button type="button" class="btn btn-reddit">Reddit <span class="btn-icon-right"><i
                                            class="fa fa-reddit"></i></span>
                                </button>
                                <button type="button" class="btn btn-spotify">Spotify <span class="btn-icon-right"><i
                                            class="fa fa-spotify"></i></span>
                                </button>
                                <button type="button" class="btn btn-yahoo">Yahoo <span class="btn-icon-right"><i
                                            class="fa fa-yahoo"></i></span>
                                </button>
                                <button type="button" class="btn btn-dribbble">Dribbble <span class="btn-icon-right"><i
                                            class="fa fa-dribbble"></i></span>
                                </button>
                                <button type="button" class="btn btn-skype">Skype <span class="btn-icon-right"><i
                                            class="fa fa-skype"></i></span>
                                </button>
                                <button type="button" class="btn btn-quora">Quora <span class="btn-icon-right"><i
                                            class="fa fa-quora"></i></span>
                                </button>
                                <button type="button" class="btn btn-vimeo">Vimeo <span class="btn-icon-right"><i
                                            class="fa fa-vimeo"></i></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2019</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
    <script src="./js/quixnav-init.js"></script>
    <script src="./js/custom.min.js"></script>
    



</body>

</html>