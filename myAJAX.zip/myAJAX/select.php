<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>
<body>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Role</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>

  <?php
include("connection.php");

$i =1;
  $data =   mysqli_query($con,"SELECT users.id,users.name,users.email,roles.name as role_name FROM users inner join roles on users.role_id = roles.id where users.role_id = ".$_GET["role_id"]." ");
  while($roles = mysqli_fetch_array($data)){
?>

    <tr>
      <th scope="row"><?php echo $i; ?></th>
      <td><?php echo $roles["name"] ?></td>
      <td><?php echo $roles["email"] ?></td>
      <td><?php echo $roles["role_name"] ?></td>
      <td></td>

    </tr>


<?php $i++; } ?>

   
  </tbody>
</table>
    
</body>
</html>