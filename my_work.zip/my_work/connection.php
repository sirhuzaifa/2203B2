<?php
$cn=mysqli_connect('localhost','root','','MY_WORK');

if(isset($_POST["btn"])){
    mysqli_query($cn,"insert into employee(name,email,password) values ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["password"]."')");
    echo "<script>alert('inserted')</script>";
};

?>


