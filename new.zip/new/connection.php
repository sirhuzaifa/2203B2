<?php

$con = mysqli_connect("localhost","root","","2203b21");

?>