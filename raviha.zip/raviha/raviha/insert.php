<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<style>
    body{
       background-image:url("bg.webp");
       background-size:cover;
    }
    h1{
        text-align:center;
    }
    form{
        font-size:20px;
    }
</style>

</head>

<body>

 <?php 
 include("nav.php");
?>

<h1>insert</h1>


<form method="POST">
  <input type="username" name="username" class="form-control" placeholder="enter Your name" >
  <br>
  <input type="email" name="useremail" class="form-control" placeholder="enter Your email" >
  <br>
  <input type="password" name="userpassword" class="form-control" placeholder="enter Your password" >
  <br>
  <button type="submit" name="btn" class="btn btn-dark">SUBMIT</button>
</form>
    
<?php
include("footer.php");
?>







<?php
insert_query("btn","insert into raviha(username,email,password) values('".$_POST["username"]."','".$_POST["useremail"]."','".$_POST["userpassword"]."')");

function insert_query($btn_name,$query){
  include('connection.php');
  if(isset($_POST[$btn_name])){
    mysqli_query($con,$query);
    echo "<script>alert('Inserted')</script>";
  }
}

?>






</body>
</html>