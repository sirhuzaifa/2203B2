<?php

$con = mysqli_connect('localhost','root','','1367910');


?>