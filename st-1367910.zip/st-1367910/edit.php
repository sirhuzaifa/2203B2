<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT DATA</title>
</head>
<body>

<h1>EDIT DATA</h1>
    <?php
    include("navbar.php");

    include("connection.php");

    $data = mysqli_query($con ,"select * from students where id = ". $_GET["id"] ." ");
    if($std_data= mysqli_fetch_array($data)){
        ?>

        <form method="post">
        <input type="text" name="username" class="form-control" value="<?php echo $std_data["name"]?>">
        <input type="email" name="useremail" class="form-control" value="<?php echo $std_data["email"]?>">
        <button name="btn" class="btn btn-warning" type="submit"  >update</button>
        </form>
        <?php
    }?>
    <?php
    include("footer.php");
    ?>
    <?php
    include("connection.php");
    ?>
    <?php
if(isset($_POST["btn"])){

    mysqli_query($con,"update students set name = '".$_POST["username"]."' ,email = '".$_POST["useremail"]."'  where id = ".$_GET["id"]." ");
    echo "<script>alert('Updated')</script>";
    echo "<script>window.location.assign('show_data.php')</script>";
    
}

    ?>

    


</body>
</html>