<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>insert data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<style>
    html body{
        background-color: bisque;
    }
    h1{
        text-align:center;
        
       
    }
    label{
        color:brown;
        font-weight:700;
        font-size:20px;
    }
    #c1{
        border:2px solid brown;
        padding:10px;
        border-radius:10px;
    }
    .btn{
        background-color:brown;
    }
</style>
</head>
<body>

    <?php
    include("navbar.php");
    ?>
<h1 >"STUDENTS! INSERT DATA HERE"</h1>
<div class="container">
 <form method="post" enctype="multipart/form-data">

    <label for="name">NAME</label><br>
    <input type="text" name="name" id="c1" class="form-control" placeholder="enter name"><br>
    <label for="email">EMAIL</label><br>
    <input type="email" name="email" id="c1" class="form-control" placeholder="enter email" ><br>
    <label for="password">password</label><br>
    <input type="password" name="password" id="c1" class="form-control" placeholder="enter password"><br>
    <label for="file">choose file</label><br>
    <input type="file" name="userfile" id="c1"  class="form-control"><br>
    <input type="submit"  class="btn btn-warning " name="btn"><br><br>

 </form>
</div>



 

 <?php
 include("footer.php");


include("function.php");

 insert_query("btn","insert into students(name,email,password) values ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["password"]."')");
 





 
 ?>





</body>
</html>