<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>show data</title>
</head>
<body>
    <?php
    include("navbar.php");
    ?>
<table class="table">
    <tr>
        <th>#</th>
        <th>name</th>
        <th>email</th>
        <th>password</th>
        <th>action</th>
    </tr>


<?php
 include("connection.php");
 $data= mysqli_query($con,"select * from students");
 $i = 1;
while( $user_data= mysqli_fetch_array($data)){
?>

    <tr>
        <th><?php echo $i   ?></th>
        <td ><?php echo $user_data["name"]  ?></td>
        <td ><?php echo $user_data["email"] ?></td>
        <td><?php echo $user_data["password"]  ?></td>
        <td><a class="btn btn-danger"  href="delete.php?id=<?php echo $user_data["id"]?>">delete</a>
        <td><a class="btn btn-success" href="edit.php?id=<?php echo $user_data["id"] ?>">Edit</a></td>
    </tr>

 <?php
$i++;};
?>

</table>

<?php
include("footer.php")
?>

</body>
</html>