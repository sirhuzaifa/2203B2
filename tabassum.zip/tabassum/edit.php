<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<style>
  body{
    background-color:lightblue;
    font-size:20px;
  }
  h1{
    text-align:center;
  }
  form{
        font-size:20px;
        text-align:center;
       
    }
  
</style>

</head>

<body>

 <?php 
 include("nav.php");
?>


<h1>EDIT</h1>

<?php
include("connection.php");
$data = mysqli_query($con, "select * from users where id =".$_GET["id"]." ");
if($std_data = mysqli_fetch_array($data)){
?>

<div class="container">
<form method="POST">
  <input type="username" name="username" class="form-control" value="<?php echo $std_data["name"] ?>" placeholder="enter Your name"  style="text-align:center; font-size:20px;" >
  <br>
  <input type="email" name="useremail" class="form-control" value="<?php echo $std_data["email"] ?>" placeholder="enter Your email"  style="text-align:center; font-size:20px;" >
  <br>
  <button type="submit" name="btn" class="btn btn-dark" style="margin-bottom:5%; font-size:20px;">UPDATE</button>
</form>
</div>
   <?php } ?> 

<?php
include("footer.php");
?>

<?php
include("connection.php");
if(isset($_POST["btn"])){
mysqli_query($con,"update users set name ='".$_POST["username"]."',email = '".$_POST["useremail"]."' where id = ".$_GET["id"]." ");
echo "<script>alert('UPDATED')<script>";
echo "<script>window.location.assign('showdata.php')<script>";
}

?>




</body>
</html>